# 현재 테스트 지식 — 자동 갱신

소스 지문: `e8166a21f3581e19f2111ca367732012bb954898b3414d50493518f35c159a04`
기존 테스트의 존재는 검증 근거가 아니다. 실행 결과도 당시 소스에 대한 근거다.

## 발견한 테스트 원문 (품질 미판정)

- `src/test/java/org/yht/excel/ExcelMappingAndSavingProgram.java`
- `src/test/java/org/yht/exps/express/controller/bms/BmsUniPassControllerTest.java`
- `src/test/java/org/yht/exps/express/ftp/ftpFileTest.java`
- `src/test/java/org/yht/ustd/monitoring/ApplicationTests.java`

## 검토하여 등록한 클래스

- 없음

## 최근 실행 근거 (최대 20개)

- 실행 기록 없음. 업무 동작은 미검증.
